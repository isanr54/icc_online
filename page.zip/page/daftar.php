<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/js/materialize.min.js"></script>
</head>
<body>
  <!-- Navbar -->
  <div class="navbar-fixed" >
    <nav class="blue" id="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <a href="#" class="brand-logo">ICC Online</a>
                <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
            </div>
        </div>
    </nav>
  </div>

  <div class="container">
    <div class="col s12 m7">
        <h2 class="header">Silahkan Hubungi CS Kami</h2>
        <div class="card horizontal">
        <div class="card-stacked">
            <div class="card-content">
                <div class="text-center">
                    <p>Untuk Mendaftarkan Akun Anda Bisa Dengan 2 Cara : </p>
                    <p>1. Hubungi CS ICC = 081395563858</p>
                    <p>2. Kunjungi Retail Store Kami</p>
                    <p>Terima Kasih</p>
                    <a href="../index.php">Kembali Ke Beranda</a>
                </div>
            </div>
        </div>
        </div>
    </div>
  </div>
</body>
</html>